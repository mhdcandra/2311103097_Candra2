<form method="GET" action="proses.php">
    Nama: <input type="text" name="nama">
    <input type="submit">
</form>