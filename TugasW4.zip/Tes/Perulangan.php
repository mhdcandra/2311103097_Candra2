<?php
$buah = ["Apel", "Jeruk", "Mangga","Durian"];
foreach ($buah as $b) {
    echo "Buah: $b <br>";
}
?>